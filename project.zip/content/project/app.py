import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session
from pyngrok import ngrok
from db import init_db, save_user_data
from models import generate_image, generate_video  # Assuming model functions are moved to models.py

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)

# Set up ngrok authentication (replace 'your_ngrok_token' with your actual ngrok auth token)
ngrok.set_auth_token("2q7utm7avEDPmWFRQM0yd7p8mFg_482jGCmDPSE1YxtzBDbJt")

# Set up ngrok tunnel
public_url = ngrok.connect(5000).public_url
print(f"Flask app is publicly accessible at: {public_url}")

# Routes for login, home page, etc.
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user_id = request.form.get("user_id")
        if user_id:
            session["user_id"] = user_id
            return redirect(url_for("home"))
    return render_template("login.html")







# @app.route("/", methods=["GET", "POST"])
# def home():
#     if "user_id" not in session:
#         return redirect(url_for("login"))

#     user_id = session["user_id"]
#     status = None

#     if request.method == "POST":
#         prompt = request.form.get("prompt")
#         if prompt:
#             status = "Processing"
#             save_user_data(user_id, prompt, status)
            
#             # Generate image and video
#             images, image_urls = generate_image(prompt, user_id)
#             videos, video_urls = generate_video(prompt, user_id)

#             # Save user data after generation
#             status = "Completed"
#             save_user_data(user_id, prompt, status)

#     return render_template("home.html", user_id=user_id, image_urls=image_urls, video_urls=video_urls, status=status)

@app.route("/", methods=["GET", "POST"])
def home():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    # Save images and videos under /content/generated_content/{user_id}/
    static_user_dir = os.path.join("/content/generated_content", user_id)
    os.makedirs(static_user_dir, exist_ok=True)

    # Initialize variables to avoid UnboundLocalError
    image_urls = []
    video_urls = []
    status = None

    if request.method == "POST":
        prompt = request.form.get("prompt")
        if prompt:
            neg_prompt = "ugly, blurry, poor quality"

            # Update status to 'Processing' in the database
            status = "Processing"
            save_user_data(user_id, prompt, [], [], status)

            try:
                # Generate 2 images
                images = image_pipe(
                    prompt,
                    negative_prompt=neg_prompt,
                    num_images_per_prompt=2,  # Increased to 2 images
                    num_inference_steps=10    # Efficient step count
                ).images
            except IndexError:
                images = image_pipe(
                    prompt,
                    negative_prompt=neg_prompt,
                    num_images_per_prompt=2,
                    num_inference_steps=10
                ).images

            # Save the 2 generated images
            image_paths = [] 
            for i, img in enumerate(images):
                img_path = os.path.join(static_user_dir, f"image_{i+1}.png")
                img.save(img_path)
                image_paths.append(img_path)
                image_urls.append(url_for('serve_user_file', user_id=user_id, filename=f"image_{i+1}.png"))

            # Generate 2 videos
            video_paths = []
            for v_idx in range(2):  # Loop for 2 videos
                video_path = os.path.join(static_user_dir, f"video_{v_idx+1}.mp4")
                video_frames = video_pipe(prompt, negative_prompt="low quality", num_inference_steps=6).frames
                rgb_frames = process_frames(video_frames)
                save_video(rgb_frames, video_path)
                video_paths.append(video_path)
                video_urls.append(url_for('serve_user_file', user_id=user_id, filename=f"video_{v_idx+1}.mp4"))

            # Update status to 'Completed' in the database
            status = "Completed"
            save_user_data(user_id, prompt, image_paths, video_paths, status)

    return render_template("home.html", user_id=user_id, image_urls=image_urls, video_urls=video_urls, status=status)

if __name__ == "__main__":
    init_db()  # Initialize DB
    app.run(port=5000)
