from diffusers import StableDiffusionXLPipeline, DiffusionPipeline
import torch
import os
from PIL import Image
import numpy as np
import imageio

# Load models
image_pipe = StableDiffusionXLPipeline.from_pretrained("segmind/SSD-1B", torch_dtype=torch.float16)
video_pipe = DiffusionPipeline.from_pretrained("damo-vilab/text-to-video-ms-1.7b", torch_dtype=torch.float16)

def generate_image(prompt, user_id):
    images = image_pipe(prompt).images
    image_paths = []
    image_urls = []
    user_dir = os.path.join("static/generated_content", user_id)
    os.makedirs(user_dir, exist_ok=True)
    
    for i, img in enumerate(images):
        img_path = os.path.join(user_dir, f"image_{i+1}.png")
        img.save(img_path)
        image_paths.append(img_path)
        image_urls.append(f"/static/generated_content/{user_id}/image_{i+1}.png")
    
    return images, image_urls

def generate_video(prompt, user_id):
    video_frames = video_pipe(prompt).frames
    video_path = os.path.join("static/generated_content", user_id, "video.mp4")
    
    # Process and save video
    rgb_frames = [np.array(Image.fromarray(frame).convert("RGB")) for frame in video_frames]
    with imageio.get_writer(video_path, fps=10) as writer:
        for frame in rgb_frames:
            writer.append_data(frame)
    
    video_urls = [f"/static/generated_content/{user_id}/video.mp4"]
    return video_frames, video_urls
